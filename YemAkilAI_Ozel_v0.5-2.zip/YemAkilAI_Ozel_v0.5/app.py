from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path
from typing import Any
import html
import json
import re

import httpx
from fastapi import FastAPI
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles

APP_DIR = Path(__file__).resolve().parent
DATA_DIR = APP_DIR / "data"
DATA_DIR.mkdir(exist_ok=True)
CACHE_FILE = DATA_DIR / "latest.json"

TRACKED_PRODUCTS = [
    "Mısır", "Arpa", "Buğday", "Soya Küspesi", "Ayçiçeği Küspesi",
    "Kanola Küspesi", "Pamuk Tohumu Küspesi", "Kepek", "DDGS", "Melas",
    "Bitkisel Yağ", "Mermer Tozu", "DCP", "Soda", "Tuz", "Premiks",
    "Vitamin", "Maya"
]

PRODUCT_EMOJI = {
    "Mısır": "🌽", "Arpa": "🌾", "Buğday": "🌾", "Soya Küspesi": "🌱",
    "Ayçiçeği Küspesi": "🌻", "Kanola Küspesi": "🌿", "Pamuk Tohumu Küspesi": "🌰",
    "Kepek": "🌾", "DDGS": "🟡", "Melas": "🍯", "Bitkisel Yağ": "🛢️",
    "Mermer Tozu": "🪨", "DCP": "⚪", "Soda": "🧂", "Tuz": "🧂",
    "Premiks": "🧪", "Vitamin": "💊", "Maya": "🟤"
}

SOURCES = {
    "turib": "https://www.turib.com.tr/",
    "ktb": "https://www.ktb.org.tr/",
}

app = FastAPI(title="YemAkıl AI – Özel Sürüm", version="0.5")
app.mount("/static", StaticFiles(directory=APP_DIR / "static"), name="static")


def clean_text(raw: str) -> str:
    raw = re.sub(r"(?is)<script.*?>.*?</script>", " ", raw)
    raw = re.sub(r"(?is)<style.*?>.*?</style>", " ", raw)
    raw = re.sub(r"(?s)<[^>]+>", "\n", raw)
    raw = html.unescape(raw).replace("\xa0", " ")
    raw = re.sub(r"[ \t]+", " ", raw)
    return re.sub(r"\n\s*\n+", "\n", raw).strip()


def tr_float(value: str) -> float:
    value = value.replace("₺", "").replace("TL", "").replace("%", "").strip()
    value = value.replace(".", "").replace(",", ".")
    match = re.search(r"-?\d+(?:\.\d+)?", value)
    if not match:
        raise ValueError(f"Sayı okunamadı: {value}")
    return float(match.group(0))


def parse_turib(raw: str) -> list[dict[str, Any]]:
    text = clean_text(raw)
    labels = {"Buğday": "Buğday Ekmeklik", "Mısır": "Mısır", "Arpa": "Arpa"}
    rows: list[dict[str, Any]] = []
    for product, label in labels.items():
        pattern = re.compile(
            re.escape(label) + r".{0,220}?(\d{1,3}[.,]\d{1,4}).{0,100}?%?\s*(-?\d{1,3}[.,]\d{1,3})",
            re.I | re.S,
        )
        match = pattern.search(text)
        if not match:
            continue
        price_kg = tr_float(match.group(1))
        change = tr_float(match.group(2))
        rows.append({
            "product": product,
            "emoji": PRODUCT_EMOJI[product],
            "price_tl_kg": price_kg,
            "price_tl_ton": round(price_kg * 1000, 2),
            "change_percent": change,
            "source": "TÜRİB",
            "source_url": SOURCES["turib"],
            "status": "current",
        })
    return rows


def parse_ktb(raw: str) -> list[dict[str, Any]]:
    text = clean_text(raw)
    mappings = {
        "Arpa": [r"2\.GRUP ARPA", r"1\.GRUP ARPA"],
        "Mısır": [r"MISIR 2\.GRUP", r"MISIR 1\.GRUP"],
        "Buğday": [r"2\.GRUP DİĞER KIRMIZI EKMEKLİK BUĞDAYLAR", r"1\.GRUP KIRMIZI SERT EKMEKLİK BUĞDAYLAR"],
    }
    rows: list[dict[str, Any]] = []
    for product, patterns in mappings.items():
        for label in patterns:
            pattern = re.compile(
                label + r".{0,500}?En Az\s*:?\s*([\d.,]+).*?En Çok\s*:?\s*([\d.,]+).*?Ortalama\s*:?\s*([\d.,]+)",
                re.I | re.S,
            )
            match = pattern.search(text)
            if not match:
                continue
            low, high, avg = [tr_float(v) for v in match.groups()]
            rows.append({
                "product": product,
                "emoji": PRODUCT_EMOJI[product],
                "price_tl_kg": avg,
                "price_tl_ton": round(avg * 1000, 2),
                "min_tl_ton": round(low * 1000, 2),
                "max_tl_ton": round(high * 1000, 2),
                "change_percent": None,
                "source": "Konya Ticaret Borsası",
                "source_url": SOURCES["ktb"],
                "status": "current",
            })
            break
    return rows


async def fetch_text(client: httpx.AsyncClient, url: str) -> str:
    response = await client.get(url, headers={
        "User-Agent": "Mozilla/5.0 YemAkilAI/0.5",
        "Accept-Language": "tr-TR,tr;q=0.9",
    })
    response.raise_for_status()
    return response.text


def load_cache() -> dict[str, Any] | None:
    try:
        return json.loads(CACHE_FILE.read_text(encoding="utf-8"))
    except Exception:
        return None


def save_cache(payload: dict[str, Any]) -> None:
    CACHE_FILE.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")


def decision_for(change: float | None) -> tuple[str, str]:
    if change is None:
        return "İZLE", "Karar için değişim verisi bekleniyor."
    if change <= -1.0:
        return "AL", "Günlük geri çekilme alım fırsatı oluşturabilir."
    if change >= 1.0:
        return "DİKKAT", "Yükseliş hızlandı; büyük alım öncesi teyit gerekli."
    return "BEKLE", "Fiyat hareketi sınırlı; yeni sinyal beklenebilir."


def build_ai_summary(items: list[dict[str, Any]]) -> dict[str, Any]:
    decisions = []
    for item in items:
        decision, reason = decision_for(item.get("change_percent"))
        row = dict(item)
        row["decision"] = decision
        row["reason"] = reason
        decisions.append(row)

    al = [x for x in decisions if x["decision"] == "AL"]
    bekle = [x for x in decisions if x["decision"] == "BEKLE"]
    dikkat = [x for x in decisions if x["decision"] == "DİKKAT"]
    izle = [x for x in decisions if x["decision"] == "İZLE"]

    if al:
        headline = f"Bugün {', '.join(x['product'] for x in al[:2])} tarafında geri çekilme öne çıkıyor."
    elif dikkat:
        headline = f"Bugün {', '.join(x['product'] for x in dikkat[:2])} tarafındaki yükseliş yakından izlenmeli."
    else:
        headline = "Bugün güçlü bir alım veya satış sinyali oluşmadı."

    return {
        "headline": headline,
        "groups": {"AL": al, "BEKLE": bekle, "DİKKAT": dikkat, "İZLE": izle},
        "note": "Kararlar yalnızca bağlanan güncel piyasa verisine göre otomatik üretilir; nihai satın alma kararı değildir.",
    }


async def build_report() -> dict[str, Any]:
    items: list[dict[str, Any]] = []
    errors: list[str] = []

    timeout = httpx.Timeout(20.0)
    async with httpx.AsyncClient(timeout=timeout, follow_redirects=True) as client:
        for name, parser in (("TÜRİB", parse_turib), ("KTB", parse_ktb)):
            try:
                url = SOURCES["turib"] if name == "TÜRİB" else SOURCES["ktb"]
                parsed = parser(await fetch_text(client, url))
                if not parsed:
                    errors.append(f"{name}: sayfa okundu fakat fiyat alanları bulunamadı.")
                items.extend(parsed)
            except Exception as exc:
                errors.append(f"{name}: veri alınamadı ({type(exc).__name__}).")

    # Aynı ürün birden fazla kaynaktan gelirse ilk kaynağı ana kart yap.
    deduped: dict[str, dict[str, Any]] = {}
    for item in items:
        deduped.setdefault(item["product"], item)
    items = list(deduped.values())

    found = {item["product"] for item in items}
    unavailable = [{
        "product": product,
        "emoji": PRODUCT_EMOJI[product],
        "status": "source_pending",
        "message": "Güvenilir ve düzenli otomatik fiyat kaynağı henüz bağlanmadı.",
    } for product in TRACKED_PRODUCTS if product not in found]

    payload = {
        "ok": bool(items),
        "updated_at": datetime.now(timezone.utc).isoformat(),
        "items": items,
        "analysis": build_ai_summary(items),
        "unavailable": unavailable,
        "errors": errors,
        "tracked_count": len(TRACKED_PRODUCTS),
        "connected_count": len(items),
        "disclaimer": "Borsa fiyatları nakliye, vade, kalite, bölge ve satıcı marjını içermeyebilir.",
    }
    if items:
        save_cache(payload)
        return payload

    cached = load_cache()
    if cached:
        cached["ok"] = True
        cached["using_cache"] = True
        cached["errors"] = errors + ["Canlı kaynaklara ulaşılamadı; son başarılı kayıt gösteriliyor."]
        return cached
    return payload


@app.get("/")
async def home() -> FileResponse:
    return FileResponse(APP_DIR / "static" / "index.html")


@app.get("/manifest.webmanifest")
async def manifest() -> FileResponse:
    return FileResponse(APP_DIR / "static" / "manifest.webmanifest")


@app.get("/service-worker.js")
async def service_worker() -> FileResponse:
    return FileResponse(APP_DIR / "static" / "service-worker.js")


@app.get("/api/report")
async def report() -> JSONResponse:
    return JSONResponse(await build_report())


@app.get("/api/health")
async def health() -> dict[str, str]:
    return {"status": "ok", "version": "0.5"}
