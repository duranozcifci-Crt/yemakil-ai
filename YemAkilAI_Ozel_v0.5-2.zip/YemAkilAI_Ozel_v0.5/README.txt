YemAkıl AI – Özel Sürüm v0.5

Bu sürümde:
- A ve B ana ekranları birleştirildi.
- Üst bölümde AL / BEKLE / DİKKAT karar özeti bulunur.
- Alt bölümde canlı fiyat, günlük değişim ve karar rozeti birlikte gösterilir.
- 18 hammaddenin tamamı listelenir; kaynağı henüz bağlı olmayanlar açıkça belirtilir.
- Gerçek veri bulunmadan örnek veya uydurma fiyat gösterilmez.

Çalıştırma:
1) pip install -r requirements.txt
2) uvicorn app:app --host 0.0.0.0 --port 8000
3) Tarayıcıdan http://localhost:8000
